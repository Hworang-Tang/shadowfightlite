# ShadowFightLite

A tiny 2D browser fighting demo (3 stages) made with plain HTML/CSS/JavaScript.
Controls:
- Move: ← → or A D
- Attack: J
- Block: K
- Restart: R

How to use:
1. Open `index.html` in your browser.
2. To publish on GitHub Pages:
   - Create a new repository on GitHub.
   - Upload the files (`index.html`, `style.css`, `main.js`) to the repository root.
   - In the repo Settings → Pages, choose `main` branch and `/ (root)` folder, save.
   - Your game will be available at `https://YOUR-USERNAME.github.io/REPO-NAME/`

This project is free and self-contained.